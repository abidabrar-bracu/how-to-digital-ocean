from variables import *

welcome_message = "Hi!, I am the bot for {}. Welcome to **{}**! Please carefully read the instructions in the <#936612448822235167> and the <#936612448822235168> channels".format(bot_name, server_name)
msg_if_username_matches = "You can now access all the channels of the **{}** server.".format(server_name)
msg_if_username_doesnt_matches = "Please send me your student ID here, otherwise you cannot access the channels of the {} server".format(server_name)
msg_if_not_found_in_database = "Sorry, I could not find your student ID in the {} database".format(server_name)
msg_if_msg_not_contain_ID = "Sorry, your message does not contain your student ID. Please send me your student ID here, otherwise you cannot access the channels of the {} server".format(server_name)
