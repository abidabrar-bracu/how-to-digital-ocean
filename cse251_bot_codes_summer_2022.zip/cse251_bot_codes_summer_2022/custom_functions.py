import numpy as np
import pandas as pd
import discord
import re
# from google_sheets_codes import *
# from variables import *
# from messages_string import *



async def set_nickname(member, student_id, student_name):
    nick_to_set = "[{}] {}".format(student_id, student_name)
    await member.edit(nick=nick_to_set[:32]) 

async def send_text_message_to(txt_msg, to_mem):
    #print(len(txt_msg))
    allowed_mentions = discord.AllowedMentions(everyone = True, users=True, roles=True)
    try:
        if len(txt_msg) <= 2000:
            await to_mem.send(content=txt_msg, allowed_mentions = allowed_mentions) 
        elif len(txt_msg) <= 4000:
            idx = txt_msg[:2000].rfind("\n") + 1
            if idx == 0:
                idx = 2000
            await to_mem.send(content=txt_msg[:idx], allowed_mentions = allowed_mentions) 
            await to_mem.send(content=txt_msg[idx:], allowed_mentions = allowed_mentions) 
            
        elif len(txt_msg) <= 6000:
            idx = txt_msg[:2000].rfind("\n") + 1
            idx2 = txt_msg[:4000].rfind("\n") + 1
            if idx == 0:
                idx = 2000
        
            if idx2 == 0:
                idx = 4000
            await to_mem.send(content=txt_msg[:idx], allowed_mentions = allowed_mentions) 
            await to_mem.send(content=txt_msg[idx:idx2], allowed_mentions = allowed_mentions)
            await to_mem.send(content=txt_msg[idx2:], allowed_mentions = allowed_mentions)
    except:
        print("failed to send message to " +  to_mem.name)

async def find_id_and_do(member, df_id_name, sec_to_role, all_sec_roles,\
                        regex_to_srch, \
                        text_to_srch, \
                        msg_to_send_if_found = None, \
                        msg_to_send_if_not_found_id = None, \
                        msg_to_send_if_found_but_not_in_db = None, \
                        role_to_remove_if_found = None, \
                        role_to_add_if_not_found = None, \
                        set_nickname_if_found=False, \
                        just_joined = False):
    
    match_obj = re.search(regex_to_srch, text_to_srch)
    any_sec_role = {role for role in member.roles if role in all_sec_roles}

    if match_obj:
        student_id = match_obj.group()

        if student_id in df_id_name.index:
            section = df_id_name.loc[student_id]["Section"]
            section_role = sec_to_role[section]

            # --------------------------------------------------------------------
            # HANDLE SECTION
            # --------------------------------------------------------------------
            if not any_sec_role:
                await member.add_roles(section_role[0])
                await member.add_roles(section_role[1])
            elif (len(any_sec_role) != 2) or (section_role[0] not in any_sec_role):
                for i_sec_role in any_sec_role:
                    await member.remove_roles(i_sec_role)
                await member.add_roles(section_role[0])
                await member.add_roles(section_role[1])
            else:
                pass 
                # ekhane asha mane sec_role thikvabe assign kora ase
            # --------------------------------------------------------------------

            if msg_to_send_if_found:
                await send_text_message_to(msg_to_send_if_found, member)
                # await member.send(content=msg_to_send_if_found)
         
            if role_to_remove_if_found:
                await member.remove_roles(role_to_remove_if_found)

            if set_nickname_if_found:
                student_name = str(df_id_name.loc[student_id]["Name"]).title()
                
                await set_nickname(member, student_id, student_name)
        else:
            # ----------------------------------------
            # REMOVE ALL SECTION RELATED ROLES
            # ----------------------------------------
            for sec_role in any_sec_role:
                await member.remove_roles(sec_role)
            # ----------------------------------------

            if msg_to_send_if_found_but_not_in_db:
                await send_text_message_to(msg_to_send_if_found_but_not_in_db, member)
                # await member.send(content=msg_to_send_if_found_but_not_in_db)
            if role_to_add_if_not_found:
                await member.add_roles(role_to_add_if_not_found)


    else:
        # not found id in the text or username or nickname
        # ----------------------------------------
        # REMOVE ALL SECTION RELATED ROLES
        # ----------------------------------------
        for sec_role in any_sec_role:
            await member.remove_roles(sec_role)
        # ----------------------------------------

        if role_to_add_if_not_found:
            await member.add_roles(role_to_add_if_not_found)

        if msg_to_send_if_not_found_id:
            await send_text_message_to(msg_to_send_if_not_found_id, member)
            # await member.send(content=msg_to_send_if_not_found_id)
    pass