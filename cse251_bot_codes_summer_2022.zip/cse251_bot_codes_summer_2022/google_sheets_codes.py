import pickle
import os.path
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
import pandas as pd



SCOPES = ['https://www.googleapis.com/auth/spreadsheets']
SPREADSHEET_ID = '1_1_vTczp7-zsQPWf11Xme7vAgD7d7ZOYtQvFsSFEsmw'
DATA_TO_PULL = 'StudentList!B:C'


def gsheet_api_check(SCOPES):
    creds = None
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)
    return creds



def pull_sheet_data(SCOPES,SPREADSHEET_ID,DATA_TO_PULL):
    creds = gsheet_api_check(SCOPES)
    service = build('sheets', 'v4', credentials=creds)
    sheet = service.spreadsheets()
    result = sheet.values().get(
        spreadsheetId=SPREADSHEET_ID,
        range=DATA_TO_PULL).execute()
    values = result.get('values', [])
    
    if not values:
        print('No data found.')
    else:
        rows = sheet.values().get(spreadsheetId=SPREADSHEET_ID,
                                  range=DATA_TO_PULL).execute()
        data = rows.get('values')
        print("COMPLETE: Data copied")
        return data

def push_sheet_data(SCOPES,SPREADSHEET_ID,DATA_TO_PUSH,SHEET_TO_PUSH,COLUMN_TO_START_PUSH,ROW_TO_START_PUSH):
    creds = gsheet_api_check(SCOPES)
    service = build('sheets', 'v4', credentials=creds)
    sheet = service.spreadsheets()
    n_row = len(DATA_TO_PUSH)
    n_col = len(DATA_TO_PUSH[0]) 
    n_clear = 1000

    # FIRST CLEAN ALL
    DATA_BLANK = [["" for _ in range(6)] for _ in range(n_clear)]
    COLUMN_TO_END_PUSH = str(chr(ord(COLUMN_TO_START_PUSH)+6-1 ))
    ROW_TO_END_PUSH = str(int(ROW_TO_START_PUSH) + n_clear - 1)
    RANGE_TO_PUSH = SHEET_TO_PUSH + "!" + COLUMN_TO_START_PUSH+ROW_TO_START_PUSH+":"+COLUMN_TO_END_PUSH+ROW_TO_END_PUSH
    _ = sheet.values().update(spreadsheetId=SPREADSHEET_ID,range=RANGE_TO_PUSH, body={"values":DATA_BLANK}, valueInputOption = "RAW").execute()

    # THEN PUSH ACTUAL DATA
    COLUMN_TO_END_PUSH = str(chr(ord(COLUMN_TO_START_PUSH) + n_col - 1))
    ROW_TO_END_PUSH = str(int(ROW_TO_START_PUSH) + n_row - 1)
    RANGE_TO_PUSH = SHEET_TO_PUSH + "!" + COLUMN_TO_START_PUSH+ROW_TO_START_PUSH+":"+COLUMN_TO_END_PUSH+ROW_TO_END_PUSH
    _ = sheet.values().update(spreadsheetId=SPREADSHEET_ID,range=RANGE_TO_PUSH, body={"values":DATA_TO_PUSH}, valueInputOption = "RAW").execute()




