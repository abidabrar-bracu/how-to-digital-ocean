import numpy as np
import pandas as pd
import discord
import re
from variables import *
from google_sheets_codes import *
from messages_string import *
from custom_functions import *
import logging
import random
from discord.utils import get



log_filename = f"log_{bot_name[:6]}_messages_spring_2022.log"
logging.basicConfig(filename=log_filename, 
					format='%(asctime)s %(levelname)s - %(message)s', 
					filemode='a') 

logger=logging.getLogger() 
logger.setLevel(logging.INFO) 

intents = discord.Intents()
intents.members = True
intents.guilds = True
intents.messages = True

client = discord.Client(intents=intents)


my_guild = 0
nick_name_not_set_properly_role = 0
faculty_role = 0
st_role = 0
all_roles = []
all_sec_roles = []
sec_to_role = []


@client.event
async def on_ready():
    print("Bot is up and running!")
    global nick_name_not_set_properly_role 
    global my_guild
    global faculty_role
    global st_role
    global all_roles
    global sec_to_role
    global all_sec_roles

    my_guild = client.get_guild(server_id)
    nick_name_not_set_properly_role = my_guild.get_role(role_to_id['NICKNAME-NOT-SET-PROPERLY'])
    faculty_role = my_guild.get_role(role_to_id['faculty'])
    st_role = my_guild.get_role(role_to_id['st'])

    all_roles = my_guild.roles
    sec_to_role = {}
    all_sec_roles = []
    for i in range(1, number_of_sections+1):
        if i not in missing_sections:
            theory_role = get(my_guild.roles, name=role_format_theory.format(i))
            lab_role = get(my_guild.roles, name=role_format_lab.format(i))
            sec_to_role[f"{i:02d}"] = [theory_role, lab_role]
            all_sec_roles.append(theory_role)
            all_sec_roles.append(lab_role)
   #sec_to_role = {re.search(r'\d+', role.name).group():role for role in all_roles if re.search(r'\d+', role.name)}

    
    # all_user_names = [mem.name for mem in my_guild.members]
    # all_user_id = [mem.id for mem in my_guild.members]
    # all_nick_name = [mem.nick for mem in my_guild.members]
    # all_role_everyone = [mem.roles[0].name if len(mem.roles) > 0 else "" for mem in my_guild.members]
    # all_role_one = [mem.roles[1].name if len(mem.roles) > 1 else "" for mem in my_guild.members]
    # all_role_two = [mem.roles[2].name if len(mem.roles) > 2 else "" for mem in my_guild.members]
    # dict = {"username":all_user_names, "id":all_user_id, "nickname":all_nick_name, "role_one":all_role_everyone, "role_two":all_role_one, "role_three":all_role_two}
    # df_mem_info = pd.DataFrame(dict)
    # df_mem_info.to_csv("cse251_fall21_info.csv", index=False)
    #print(df_mem_info.head())
    #print([role.name for role in my_guild.members[100].roles])

    print(my_guild)
    print(nick_name_not_set_properly_role)
    print(sec_to_role)



@client.event
async def on_member_join(member):

    if member.bot or not(member.guild == my_guild):
        return

    await send_text_message_to(welcome_message, member)
    # await member.send(content=welcome_message)
    # check if username matches the regex
    await find_id_and_do(member, df_id_name, sec_to_role, all_sec_roles, \
                        regex_to_srch=student_id_without_brackets_regex, \
                        text_to_srch=member.name, \
                        msg_to_send_if_found=msg_if_username_matches, \
                        msg_to_send_if_not_found_id=msg_if_username_doesnt_matches, \
                        msg_to_send_if_found_but_not_in_db=msg_if_not_found_in_database + "\n" + msg_if_username_doesnt_matches,\
                        role_to_remove_if_found=None, \
                        role_to_add_if_not_found=nick_name_not_set_properly_role,\
                        set_nickname_if_found = True, \
                        just_joined = True)        

@client.event
async def on_message(message):
    # if self message, or message from server not in the guild, return
    if message.author == client.user:
        return 

    
    # to update dashboard automatically if receive a message from bot configs channel
    if dashboard_enabled and message.channel.id == bot_command_channel_id and message.content == cmd_update_dashboard:
        global data_dash
        global df_dash 
        global data_next7
        global df_next7
        global data_status
        global df_status
        global dashboard_header
        data_dash = pull_sheet_data(SCOPES,SPREADSHEET_DASH,DATA_DASH+"A:H")
        df_dash = pd.DataFrame(data_dash[1:], columns=data_dash[0])
        df_dash = df_dash[df_dash["Publish?"]=="TRUE"]
        df_dash = df_dash.set_index("Title")

        data_next7 = pull_sheet_data(SCOPES,SPREADSHEET_DASH,DATA_DASH+"M:R")
        df_next7 = pd.DataFrame(data_next7[1:], columns=data_next7[0])
        df_next7 = df_next7.set_index("Title")
        data_status = pull_sheet_data(SCOPES,SPREADSHEET_DASH,DATA_STATUS)
        df_status = pd.DataFrame(data_status[1:], columns=data_status[0])
        df_status = df_status[df_status['Discord ID'] != '']
        df_status = df_status.set_index('Discord ID')

        dashboard_header = "**__CSE251 Fall 2021 Dashboard__**\n\n"
        dashboard_header += "**Tasks Assigned**\n"

        k = 1
        for t in df_dash.index:
            if df_dash.loc[t]["is_overdue"] == "FALSE":
                    dashboard_header += str(k) + ". " + t + " (Due - __" + df_dash.loc[t]["Deadline"] + "__)\n"
                    k += 1
                    
        dashboard_header += "\n**Tasks Overdue**\n"

        k = 1
        for t in df_dash.index:
            if df_dash.loc[t]["is_overdue"] == "TRUE":
                    dashboard_header += str(k) + ". " + t + " (Due - __" + df_dash.loc[t]["Deadline"] + "__)\n"
                    k += 1
        if k == 1:
              dashboard_header += "None\n"
        dashboard_header += "\n**Upcoming Events This Week**\n"

        k = 1
        for t in df_next7.index:
            if t == "Pop Quizzes Week2":
                continue
            dashboard_header += str(k) + ". [" + df_next7.loc[t]["Tag"] + "] " + t 
            dashboard_header += " (Time - __" + df_next7.loc[t]["Time"] + "__)\n"
            k += 1
            
        dashboard_header += "\n\n**__Personal Progress__**\n\n"
        return 

    # eta true hole personal message na, so apatoto egula ignore korbo, pore deal korbo
    elif message.guild:
        return 


    member = my_guild.get_member(message.author.id)
    if not member or member.bot:
        return # None return korse, so amar server e nai, or shala ekta bot

    logger.info(member.name+"#"+member.discriminator+" --- "+message.content)

    ''' MODERATOR COMMANDS'''
    ''' ---------------------------------------------------------------------------'''
    if member.id in owner_id:
        # means it's me, the boss
        # do SPECIAL COMMANDS
        admin_report = "**__ADMIN REPORT__**\n"

        if cmd_update_discord_list in message.content:
            all_user_names = [mem.name for mem in my_guild.members]
            all_user_id = [mem.id for mem in my_guild.members]
            all_nick_name = [mem.nick for mem in my_guild.members]
            all_role_everyone = [mem.roles[0].name if len(mem.roles) > 0 else "" for mem in my_guild.members]
            all_role_one = []
            all_role_two = []
            for mem in my_guild.members:
                if len(mem.roles) <= 1:
                    all_role_one.append("")
                    all_role_two.append("")
                elif len(mem.roles) <= 2:
                    all_role_one.append(mem.roles[1].name)
                    all_role_two.append("")
                else:
                    sorted_roles = [rl.name for rl in mem.roles[1:]]
                    sorted_roles.sort()
                    all_role_one.append(sorted_roles[0])
                    all_role_two.append(", ".join(sorted_roles[1:]))

            dict = {"username":all_user_names, "id":all_user_id, "nickname":all_nick_name, "role_one":all_role_everyone, "role_two":all_role_one, "role_three":all_role_two}
            df_mem_info = pd.DataFrame(dict)
            df_mem_info['id'] = df_mem_info['id'].astype(str)
            DATA_TO_PUSH = df_mem_info.fillna('').values.tolist()

            push_sheet_data(SCOPES,SPREADSHEET_ID,DATA_TO_PUSH,SHEET_TO_PUSH,COLUMN_TO_START_PUSH,ROW_TO_START_PUSH)
            admin_report += "Discord list updated"

        elif cmd_update_std_list in message.content:
            global df_id_name
            global data 
            global data_2
            global df_marks
            global data_3
            global df_grades
            data = pull_sheet_data(SCOPES,SPREADSHEET_ID,DATA_TO_PULL)
            df_id_name = pd.DataFrame(data[1:], columns=data[0])
            df_id_name = df_id_name.set_index('Student ID')

            data_2 = pull_sheet_data(SCOPES,SPREADSHEET_ID_2,DATA_TO_PULL_2)
            df_marks = pd.DataFrame(data_2[1:], columns=data_2[0])
            df_marks = df_marks[df_marks['Discord ID'] != '']
            df_marks = df_marks.set_index('Discord ID')

            data_3 = pull_sheet_data(SCOPES,SPREADSHEET_ID_3,DATA_TO_PULL_3)
            df_grades = pd.DataFrame(data_3[1:], columns=data_3[0])
            df_grades = df_grades[df_grades['Discord ID'] != '']
            df_grades = df_grades.set_index('Discord ID')

            admin_report += "Student list updated"

        elif message.content.startswith(cmd_send_everyone):
            
            for mem in my_guild.members:
                if mem.bot:
                    continue
                msg_to_send = message.content[len(cmd_send_everyone):].strip()
                await send_text_message_to(msg_to_send, mem)
                # await mem.send(content=msg_to_send)

            admin_report += "Done sending messages to everyone"

        elif message.content.startswith(cmd_send_to_channel):
            splitted_msg = message.content.split(":")
            if not re.search(r'\d+', splitted_msg[0]) or not my_guild.get_channel(int(re.search(r'\d+', splitted_msg[0]).group())):
            #if len(splitted_msg) != 2 or not re.search(r'\d+', splitted_msg[0]):
                admin_report += "Please use the following format\n"
                admin_report += "send to *channelID* : *message to send*"
            else:
                id_channel_to_send = int(re.search(r'\d+', splitted_msg[0]).group())
                actual_msg_to_send = ":".join(splitted_msg[1:]).strip()
                channel_to_send = my_guild.get_channel(id_channel_to_send)
                await send_text_message_to(actual_msg_to_send, channel_to_send)
                admin_report += f"Done sending message to {channel_to_send.name}"

        elif message.content.startswith(cmd_send_to_member):
            splitted_msg = message.content.split(":")
            if not re.search(r'\d+', splitted_msg[0]) or not my_guild.get_member(int(re.search(r'\d+', splitted_msg[0]).group())):
            #if len(splitted_msg) != 2 or not re.search(r'\d+', splitted_msg[0]):
                admin_report += "Please use the following format\n"
                admin_report += "send message to *<userID>* : *<message to send>*"
            else:
                id_channel_to_send = int(re.search(r'\d+', splitted_msg[0]).group())
                actual_msg_to_send = ":".join(splitted_msg[1:]).strip()
                member_to_send = my_guild.get_member(id_channel_to_send)
                await send_text_message_to(actual_msg_to_send, member_to_send)
                admin_report += f"Done sending message to {member_to_send.name}"

        #
        # ------------------------------------------------------------------------------------------------ 
        # THIS WAS USED TO GET MARKS
        # ------------------------------------------------------------------------------------------------ 
        # 
        elif message.content.startswith(cmd_check_marks) or message.content.startswith(cmd_check_marks_deets):
            # GET MARKS
            want_details = message.content.startswith(cmd_check_marks_deets)
            
            usr_name = message.content[len(cmd_check_marks_deets):].strip() if want_details else  message.content[len(cmd_check_marks):].strip()
            
            # check if i input student ID instead of user ID, in that case conver to user ID
            if usr_name.isnumeric() and len(usr_name) == 8:
                usr_name = df_id_name.loc[usr_name]["Discord ID"]

            if usr_name not in df_marks.index:
                admin_report += "\nThe Discord Username {} was not found in the {} marks database.".format(usr_name, server_name)
            else:
                marks_cols = df_marks.columns.to_numpy()
                all_marks_usr = df_marks.loc[usr_name].to_numpy()
                
                admin_report += '\n**Name**: {}'.format(df_marks.loc[usr_name]["Name"])
                admin_report += '\n**Student ID**: {}\n\n'.format(df_marks.loc[usr_name]["Student ID"])
                admin_report += '\n**Gsuite**: {}\n\n'.format(df_marks.loc[usr_name]["Gsuite"])
                for i in range(3, len(marks_cols)):
                    if marks_cols[i].startswith("----") and not want_details:
                        continue
                    admin_report += "**{}**: ".format(marks_cols[i])
                    admin_report += "{}\n".format(all_marks_usr[i])

        #   await send_text_message_to(admin_report,  member)
        #
        # ------------------------------------------------------------------------------------------------ 
        # THIS WAS USED TO GET GRADES
        # ------------------------------------------------------------------------------------------------ 
        #
        # # Gradebook    
        elif message.content.startswith(cmd_check_grades):
            
            usr_name = message.content[len(cmd_check_grades):].strip()
            
            # check if i input student ID instead of user ID, in that case conver to user ID
            if usr_name.isnumeric() and len(usr_name) == 8:
                usr_name = df_id_name.loc[usr_name]["Discord ID"]

            if usr_name not in df_grades.index:
                admin_report += "\nThe Discord Username {} was not found in the {} marks database.".format(usr_name, server_name)
            else:
                marks_cols = df_grades.columns.to_numpy()
                all_marks_usr = df_grades.loc[usr_name].to_numpy()
                admin_report += '\n**Name**: {}'.format(df_grades.loc[usr_name]["Name"])
                admin_report += '\n**Student ID**: {}\n\n'.format(df_grades.loc[usr_name]["Student ID"])
                admin_report += '\n**Gsuite**: {}\n\n'.format(df_grades.loc[usr_name]["Gsuite"])
                for i in range(5, len(marks_cols)):
                    admin_report += "**{}**: ".format(marks_cols[i])
                    admin_report += "{}\n".format(all_marks_usr[i])

            # await send_text_message_to(admin_report,  member)

        #
        # ------------------------------------------------------------------------------------------------ 
        # THIS WAS USED TO GET DASHBOARD
        # ------------------------------------------------------------------------------------------------ 
        #
        # # Dashboard 
        elif dashboard_enabled and message.content.startswith(cmd_check_dashboard):
            
            usr_name = message.content[len(cmd_check_dashboard):].strip()
            
            # check if i input student ID instead of user ID, in that case conver to user ID
            if usr_name.isnumeric() and len(usr_name) == 8:
                usr_name = df_id_name.loc[usr_name]["Discord ID"]

            if usr_name not in df_grades.index:
                admin_report += "\nThe Discord Username {} was not found in the {} dashboard database.".format(usr_name, server_name)
            else:
                admin_report += dashboard_header
                admin_report += f'**Name**: {df_status.loc[usr_name]["Name"]}'
                admin_report += f'\n**Student ID**: {df_status.loc[usr_name]["Student ID"]}'
                admin_report += f'\n**Assignment Late Count**: {df_status.loc[usr_name]["Late Count"]}'
                admin_report += f'\n**Free Late Days Remaining**: {df_status.loc[usr_name]["Free Late Days Left"]}\n\n'

                for col in df_status.columns[6:]:
                    admin_report += "**{}**: ".format(col)
                    admin_report += "{}\n".format(df_status.loc[usr_name][col])

        elif cmd_check_all in message.content:
            for mem in my_guild.members:
                if (faculty_role in mem.roles) or (st_role in mem.roles) or mem.bot:
                    continue

                if nick_name_not_set_properly_role in mem.roles:
                    msg_to_send_if_found = msg_if_username_matches
                    role_to_remove_if_found = nick_name_not_set_properly_role 
                    role_to_add_if_not_found = None
                    set_nickname_if_found = True
                else: 
                    msg_to_send_if_found = None 
                    role_to_remove_if_found = None 
                    role_to_add_if_not_found = nick_name_not_set_properly_role
                    if re.search(student_id_and_name_regex, str(mem.name)):
                        set_nickname_if_found = False
                    elif re.search(student_id_and_name_regex, str(mem.nick)):
                        set_nickname_if_found = False
                    else:
                        set_nickname_if_found = True


                await find_id_and_do(mem, df_id_name, sec_to_role, all_sec_roles, \
                        regex_to_srch=student_id_without_brackets_regex, \
                        text_to_srch=str(mem.name)+str(mem.nick), \
                        msg_to_send_if_found=msg_to_send_if_found, \
                        msg_to_send_if_not_found_id=msg_if_username_doesnt_matches, \
                        msg_to_send_if_found_but_not_in_db=msg_if_not_found_in_database + "\n" + msg_if_username_doesnt_matches,\
                        role_to_remove_if_found=role_to_remove_if_found, \
                        role_to_add_if_not_found=role_to_add_if_not_found,\
                        set_nickname_if_found = set_nickname_if_found)
            
            admin_report += "Done checking all students"
        ''' ---------------------------------------------------------------------------'''
        if admin_report == "**__ADMIN REPORT__**\n":
            admin_report += "Command not found"
        await send_text_message_to(admin_report,  member)
        return 

    # means someone else, a student
    # nickname thik ase
    # tar mane tar nickname thik ase and amar server er member
    if nick_name_not_set_properly_role not in member.roles:
        # PORE MUCHE DILE HOBE
        #'''
        #------------------------------------------------------------------------------------------------ 
        #THIS WAS USED TO GET GRADES AND MARKS BY THE STUDENTS
        #------------------------------------------------------------------------------------------------ 
        #'''
        if "mark" in message.content.lower():
            #usr_name = member.name + "#" + member.discriminator
            usr_name = str(member.id)
            if usr_name not in df_marks.index:
                msg_marks_to_send = "Your Discord Username {} was not found in the {} marks database. Please contact your faculty.".format(member.name + "#" + member.discriminator, server_name)
            else:
                marks_cols = df_marks.columns.to_numpy()
                all_marks_usr = df_marks.loc[usr_name].to_numpy()
                #student_id = df_marks.loc[usr_name]["Student ID"]
                msg_marks_to_send = '**Name**: {}'.format(df_marks.loc[usr_name]["Name"])
                msg_marks_to_send += '\n**Student ID**: {}\n\n'.format(df_marks.loc[usr_name]["Student ID"])
                for i in range(3, len(marks_cols)):
                    if marks_cols[i].startswith("----") and "detail" not in message.content.lower():
                        continue
                    msg_marks_to_send += "**{}**: ".format(marks_cols[i])
                    msg_marks_to_send += "{}\n".format(all_marks_usr[i])

            await send_text_message_to(msg_marks_to_send,  member)

        elif "grade" in message.content.lower():
            usr_name = str(member.id)
            if usr_name not in df_grades.index:
                msg_marks_to_send = "Your Discord Username {} was not found in the {} marks database. Please contact your faculty.".format(member.name + "#" + member.discriminator, server_name)
            else:
                marks_cols = df_grades.columns.to_numpy()
                all_marks_usr = df_grades.loc[usr_name].to_numpy()
                msg_marks_to_send = '**Name**: {}'.format(df_grades.loc[usr_name]["Name"])
                msg_marks_to_send += '\n**Student ID**: {}\n\n'.format(df_marks.loc[usr_name]["Student ID"])
                for i in range(5, len(marks_cols)):
                    msg_marks_to_send += "**{}**: ".format(marks_cols[i])
                    msg_marks_to_send += "{}\n".format(all_marks_usr[i])

            await send_text_message_to(msg_marks_to_send,  member)

        elif dashboard_enabled and ("dash" in message.content.lower()):
            usr_name = str(member.id)
            if usr_name not in df_grades.index:
                msg_to_send = "Your Discord Username {} was not found in the {} marks database. Please contact your faculty.".format(member.name + "#" + member.discriminator, server_name)
            else:
                msg_to_send = dashboard_header[:]
                msg_to_send += f'**Name**: {df_status.loc[usr_name]["Name"]}'
                msg_to_send += f'\n**Student ID**: {df_status.loc[usr_name]["Student ID"]}'
                msg_to_send += f'\n**Assignment Late Count**: {df_status.loc[usr_name]["Late Count"]}'
                msg_to_send += f'\n**Free Late Days Remaining**: {df_status.loc[usr_name]["Free Late Days Left"]}\n\n'

                for col in df_status.columns[6:]:
                    msg_to_send += "**{}**: ".format(col)
                    msg_to_send += "{}\n".format(df_status.loc[usr_name][col])

            await send_text_message_to(msg_to_send,  member)

        return
    

    # ekhane asshe mane 1) she amar server er member, 2) tar nickname thik kora nai
    # message content check korbo student ID dise kina.
    
    # jodi message e kothao student ID diye thake
    await find_id_and_do(member, df_id_name, sec_to_role, all_sec_roles, \
                        regex_to_srch=student_id_without_brackets_regex, \
                        text_to_srch=message.content, \
                        msg_to_send_if_found=msg_if_username_matches, \
                        msg_to_send_if_not_found_id=msg_if_username_doesnt_matches, \
                        msg_to_send_if_found_but_not_in_db=msg_if_not_found_in_database + "\n" + msg_if_username_doesnt_matches,\
                        role_to_remove_if_found=nick_name_not_set_properly_role, \
                        role_to_add_if_not_found=None,\
                        set_nickname_if_found = True)      
        
client.run(bot_token)