import numpy as np
import pandas as pd
import discord
import re
import logging
import random


server_id = 936612447652048947
role_id = 936612447652048949
role_id_lab = 936612447652048948
bot_token = "ODExMDU2ODM0MzQ1MDQxOTIw.YCspig.nl_9WeIgfY7Yv86vc8ydNx1hCYY"

intents = discord.Intents()
intents.members = True
intents.guilds = True
intents.messages = True

clone_sec_role_start = 1
clone_sec_role_end = 4

client = discord.Client(intents=intents)

@client.event
async def on_ready():
    print("Bot is up and running!")
    my_guild = client.get_guild(server_id)
    role = my_guild.get_role(role_id)
    role_lab = my_guild.get_role(role_id_lab)
    print(role.name)
    for i in range(clone_sec_role_start, clone_sec_role_end+1):
        
        name = role.name[:-2] + f"{i:02d}"
        print(name)
        await my_guild.create_role(name=name, permissions=role.permissions, colour=role.colour)
        
        name = role.name[:-2] + f"{i:02d}" + "-lab"
        print(name)
        await my_guild.create_role(name=name, permissions=role_lab.permissions, colour=role_lab.colour)

client.run(bot_token)