import pandas as pd
from google_sheets_codes import *
from custom_functions import *

bot_name = "CSE251"
role_to_id = {"NICKNAME-NOT-SET-PROPERLY": 936612447652048950, "faculty": 936612447652048953, "st": 936612447652048952}

server_name = "CSE251 Spring'22"
server_id = 936612447652048947
owner_id = [737282621129752608, 484432501687713796, 331795285565112320, 872026267459936276]
bot_command_channel_id = 936612449010974779

bot_token = "ODExMDU2ODM0MzQ1MDQxOTIw.YCspig.nl_9WeIgfY7Yv86vc8ydNx1hCYY"
student_id_and_name_regex = "\[[0-9]{8}\].*"
student_id_regex = "\[[0-9]{8}\]"
student_id_without_brackets_regex = "[0-9]{8}"
role_format_theory = "sec-{:02d}"
role_format_lab = "sec-{:02d}-lab"
number_of_sections = 14
missing_sections = []
dashboard_enabled = False

# special commands
cmd_update_std_list = "update sheets"
cmd_check_all = "check everyone"
cmd_send_everyone = "send everyone:"
cmd_check_marks = "get marks"
cmd_check_marks_deets = "get marks details"
cmd_check_grades = "get grades"
cmd_update_discord_list = "update discord list"
cmd_send_to_channel = "send to"
cmd_send_to_member = "send message to"
cmd_update_dashboard = "update dashboard"
cmd_check_dashboard = "get dashboard"

''' ---------------------------------------------------------------------------'''
''' FIRST AND FOREMOST!!!! IMPORT STUDENT LIST FROM GOOGLE SHEET! '''
SPREADSHEET_ID = '1HPKw02eG3KOZ6qalAXhd7v7Xi-IVPSYDJdvNXFVpy6Q'
DATA_TO_PULL = 'StudentList!A:N'
data = pull_sheet_data(SCOPES,SPREADSHEET_ID,DATA_TO_PULL)
df_id_name = pd.DataFrame(data[1:], columns=data[0])
df_id_name = df_id_name.set_index('Student ID')
''' ---------------------------------------------------------------------------'''

''' ---------------------------------------------------------------------------'''
''' INFO ABOUT DISCORD SHEET '''
SHEET_TO_PUSH = 'Discord'
COLUMN_TO_START_PUSH = "C"
ROW_TO_START_PUSH = "2"
''' ---------------------------------------------------------------------------'''

''' ---------------------------------------------------------------------------'''
''' Marks Sheet'''
SPREADSHEET_ID_2 = '1bx3Nqi4dLMgmO14S1XD42aKPY5lPx__cqJxEVwcpciM'
DATA_TO_PULL_2 = 'marks'
data_2 = pull_sheet_data(SCOPES,SPREADSHEET_ID_2,DATA_TO_PULL_2)
df_marks = pd.DataFrame(data_2[1:], columns=data_2[0])
df_marks = df_marks[df_marks['Discord ID'] != '']
df_marks = df_marks.set_index('Discord ID')
''' ---------------------------------------------------------------------------'''


''' ---------------------------------------------------------------------------'''
''' Grade Sheet'''
SPREADSHEET_ID_3 = '1bx3Nqi4dLMgmO14S1XD42aKPY5lPx__cqJxEVwcpciM'
DATA_TO_PULL_3 = 'grades'
data_3 = pull_sheet_data(SCOPES,SPREADSHEET_ID_3,DATA_TO_PULL_3)
df_grades = pd.DataFrame(data_3[1:], columns=data_3[0])
df_grades = df_grades[df_grades['Discord ID'] != '']
df_grades = df_grades.set_index('Discord ID')
''' ---------------------------------------------------------------------------'''


if dashboard_enabled:
    ''' ---------------------------------------------------------------------------'''
    ''' Dashboard'''
    SPREADSHEET_DASH = '1QpfV30lYuMbj5A0InU5IQSK47c2tYZHj4zE7Vja5sLw'
    DATA_DASH = 'PublishDueResponse!'
    data_dash = pull_sheet_data(SCOPES,SPREADSHEET_DASH,DATA_DASH+"A:H")
    df_dash = pd.DataFrame(data_dash[1:], columns=data_dash[0])
    df_dash = df_dash[df_dash["Publish?"]=="TRUE"]
    df_dash = df_dash.set_index("Title")

    data_next7 = pull_sheet_data(SCOPES,SPREADSHEET_DASH,DATA_DASH+"M:R")
    df_next7 = pd.DataFrame(data_next7[1:], columns=data_next7[0])
    df_next7 = df_next7.set_index("Title")

    DATA_STATUS = 'Status!A1:Z1000'
    data_status = pull_sheet_data(SCOPES,SPREADSHEET_DASH,DATA_STATUS)
    df_status = pd.DataFrame(data_status[1:], columns=data_status[0])
    df_status = df_status[df_status['Discord ID'] != '']
    df_status = df_status.set_index('Discord ID')
    ''' ---------------------------------------------------------------------------'''



    ''' ---------------------------------------------------------------------------'''
    ''' Dashboard Header'''
    dashboard_header = "**__CSE251 Fall 2021 Dashboard__**\n\n"

    dashboard_header += "**Tasks Assigned**\n"

    k = 1
    for t in df_dash.index:
        if df_dash.loc[t]["is_overdue"] == "FALSE":
                dashboard_header += str(k) + ". " + t + " (Due - __" + df_dash.loc[t]["Deadline"] + "__)\n"
                k += 1
                
    dashboard_header += "\n**Tasks Overdue**\n"

    k = 1
    for t in df_dash.index:
        if df_dash.loc[t]["is_overdue"] == "TRUE":
                dashboard_header += str(k) + ". " + t + " (Due - __" + df_dash.loc[t]["Deadline"] + "__)\n"
                k += 1
    if k == 1:
        dashboard_header += "None\n"      
    dashboard_header += "\n**Upcoming Events This Week**\n"

    k = 1
    for t in df_next7.index:
        if t == "Pop Quizzes Week2":
            continue
        dashboard_header += str(k) + ". [" + df_next7.loc[t]["Tag"] + "] " + t 
        dashboard_header += " (Time - __" + df_next7.loc[t]["Time"] + "__)\n"
        k += 1

    dashboard_header += "\n\n**__Personal Progress__**\n\n"
    ''' ---------------------------------------------------------------------------'''