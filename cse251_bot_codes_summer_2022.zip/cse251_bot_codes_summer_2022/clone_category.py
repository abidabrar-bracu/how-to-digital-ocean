import numpy as np
import pandas as pd
import discord
import re
import logging
import random
from discord.utils import get


# 251
# server_id = 936612447652048947
# bot_token = "ODExMDU2ODM0MzQ1MDQxOTIw.YCspig.nl_9WeIgfY7Yv86vc8ydNx1hCYY" 

# 250
# server_id = 936565420217999380
# bot_token = "OTM2NjE1NDUyNDQ3MjMyMDQy.YfPxHQ.7lElfiK76eZAGHfs_NyRxXpVN1Y"

#350
# server_id = 936566611203219456
# bot_token = "ODUzNzM2MjY0Mjg4MzA1MTgy.YMZt2w.LS-0Dhyg5TJ5OluVQz-xHE_qPTg"

#460
server_id = 937276805650452540
bot_token = "ODUzNzM2MjcxODI5MjcwNTY5.YMZt3A.oWxxquCXfmy0I6BQAGmn9a76uLs"

category_template = ["Section {:02d} Theory", "Section {:02d} Lab"]
role_template = ["sec-{:02d}", "sec-{:02d}-lab"]

clone_start = 2 # FIXED 
clone_end = 10 # NUMBER OF SECTIONS


intents = discord.Intents()
intents.members = True
intents.guilds = True
intents.messages = True



client = discord.Client(intents=intents)



@client.event
async def on_ready():
    print("Bot is up and running!")
    guild = client.get_guild(server_id)

    for i in range(clone_start, clone_end+1): 
        for k in range(2):
            base_category = get(guild.channels, name=category_template[k].format(1))
        
            base_role = get(guild.roles, name=role_template[k].format(1))

            category_name = category_template[k].format(i)
            role_name = role_template[k].format(i)
            print(f"Creating {category_name}......")
            new_role = await guild.create_role(name=role_name, 
                                               permissions=base_role.permissions, 
                                               colour=base_role.colour)

            new_category = await base_category.clone(name=category_name)
            for j, chan in enumerate(base_category.text_channels):
                overwrites = chan.overwrites.copy()
                overwrites[new_role] = overwrites[base_role]
                del overwrites[base_role]
                cloned = await new_category.create_text_channel(name=chan.name, overwrites=overwrites)
                await cloned.edit(category = new_category, position = j)

            shift = j + 1
            for j, chan in enumerate(base_category.voice_channels):
                overwrites = chan.overwrites.copy()
                overwrites[new_role] = overwrites[base_role]
                del overwrites[base_role]
                cloned = await new_category.create_voice_channel(name=chan.name, overwrites=overwrites)
                await cloned.edit(category = new_category, position = j+shift)
    
            print("Done!\n")

client.run(bot_token)